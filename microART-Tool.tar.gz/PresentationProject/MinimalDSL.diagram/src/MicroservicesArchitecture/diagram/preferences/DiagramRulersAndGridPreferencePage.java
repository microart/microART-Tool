/*
 * 
 */
package MicroservicesArchitecture.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	* @generated
	*/
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(MicroservicesArchitecture.diagram.part.MicroservicesArchitectureDiagramEditorPlugin
				.getInstance().getPreferenceStore());
	}
}
