/*
 * 
 */
package MicroservicesArchitecture.diagram.edit.helpers;

/**
 * @generated
 */
public class MicroServiceEditHelper
		extends MicroservicesArchitecture.diagram.edit.helpers.MicroservicesArchitectureBaseEditHelper {
}
