/*
 * 
 */
package MicroservicesArchitecture.diagram.edit.helpers;

/**
 * @generated
 */
public class ProductEditHelper
		extends MicroservicesArchitecture.diagram.edit.helpers.MicroservicesArchitectureBaseEditHelper {
}
