/*
 * 
 */
package MicroservicesArchitecture.diagram.edit.helpers;

/**
 * @generated
 */
public class DeveloperEditHelper
		extends MicroservicesArchitecture.diagram.edit.helpers.MicroservicesArchitectureBaseEditHelper {
}
