/*
 * 
 */
package MicroservicesArchitecture.diagram.edit.helpers;

/**
 * @generated
 */
public class InterfaceEditHelper
		extends MicroservicesArchitecture.diagram.edit.helpers.MicroservicesArchitectureBaseEditHelper {
}
