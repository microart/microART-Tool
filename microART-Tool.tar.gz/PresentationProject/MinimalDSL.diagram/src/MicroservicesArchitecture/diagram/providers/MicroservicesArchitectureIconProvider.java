/*
 * 
 */
package MicroservicesArchitecture.diagram.providers;

import org.eclipse.gmf.runtime.common.ui.services.icon.IIconProvider;
import org.eclipse.gmf.tooling.runtime.providers.DefaultElementTypeIconProvider;

/**
 * @generated
 */
public class MicroservicesArchitectureIconProvider extends DefaultElementTypeIconProvider implements IIconProvider {

	/**
	* @generated
	*/
	public MicroservicesArchitectureIconProvider() {
		super(MicroservicesArchitecture.diagram.providers.MicroservicesArchitectureElementTypes.TYPED_INSTANCE);
	}

}
