/*
 * 
 */
package MicroservicesArchitecture.diagram.providers;

import org.eclipse.gmf.tooling.runtime.providers.DefaultEditPartProvider;

/**
 * @generated
 */
public class MicroservicesArchitectureEditPartProvider extends DefaultEditPartProvider {

	/**
	* @generated
	*/
	public MicroservicesArchitectureEditPartProvider() {
		super(new MicroservicesArchitecture.diagram.edit.parts.MicroservicesArchitectureEditPartFactory(),
				MicroservicesArchitecture.diagram.part.MicroservicesArchitectureVisualIDRegistry.TYPED_INSTANCE,
				MicroservicesArchitecture.diagram.edit.parts.ProductEditPart.MODEL_ID);
	}

}
